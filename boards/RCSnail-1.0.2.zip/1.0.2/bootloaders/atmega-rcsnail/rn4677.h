#ifndef rn4677_h
#define rn4677_h

#include <stdint.h>

void rn4677_init(void);

#endif